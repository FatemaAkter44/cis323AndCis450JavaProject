package pkgPathway;

public class Passenger {
	private int idpass; //Passenger Id
	private String namepass; //Passenger Name
	private int ccnumpass; // Passenger Credit Card Number
	private int tinpass; //Passenger TIN
	
	Passenger()
{	idpass = 0;
	namepass = "";
	ccnumpass = 0;
	tinpass = 0;
	
	}
	
	Passenger(int i, String n, int c, int t)
{	idpass = i;
	namepass = n;
	ccnumpass = c;
	tinpass = t;

	}

	public int getIdpass() {
		return idpass;
	}

	public void setIdpass(int idpass) {
		this.idpass = idpass;
	}

	public String getNamepass() {
		return namepass;
	}

	public void setNamepass(String namepass) {
		this.namepass = namepass;
	}

	public int getCcnumpass() {
		return ccnumpass;
	}

	public void setCcnumpass(int ccnumpass) {
		this.ccnumpass = ccnumpass;
	}

	public int getTinpass() {
		return tinpass;
	}

	public void setTinpass(int tinpass) {
		this.tinpass = tinpass;
	}
}