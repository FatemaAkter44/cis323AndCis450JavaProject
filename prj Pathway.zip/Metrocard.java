package pkgPathway;

public class Metrocard {

	private int mnum;  //Metrocard number
	private float mamt;  //Metrocard amount
	
	Metrocard()
	{
		mnum = 0;
		mamt = 0.00f;
	}
	
	Metrocard (int m, float m2)//overloaded constructor
	{
		mnum = m;
		mamt = m2;
	}

	public int getMnum() {
		return mnum;
	}

	public void setMnum(int mnum) {
		this.mnum = mnum;
	}

	public float getMamt() {
		return mamt;
	}

	public void setMamt(float mamt) {
		this.mamt = mamt;
	}
}
	