package pkgPathway;

import java.sql.Date;

public class Train {
	char TNumber ; //TrainNumber
	String DStation; //DepartureStation
	String AStation; //ArrivalStation
	int BCode; //BoroughCode
    Date DTime; //DepartureTime
	Date ATime; // ArrivalTime
		

	Train()
	{
		TNumber = 'x';
		DStation = "";
		AStation = "";
		BCode = 0;
		DTime = null;
		ATime = null;
	}
		
	Train(char tn, String ds, String as, int bc)
	{
		TNumber = tn;
		DStation= ds;
		AStation = as;
		BCode = bc;
		DTime = null;
		ATime = null;
	}

	public char getTNumber() {
		return TNumber;
	}

	public void setTNumber(char tNumber) {
		TNumber = tNumber;
	}

	public String getDStation() {
		return DStation;
	}

	public void setDStation(String dStation) {
		DStation = dStation;
	}

	public String getAStation() {
		return AStation;
	}

	public void setAStation(String aStation) {
		AStation = aStation;
	}

	public int getBCode() {
		return BCode;
	}

	public void setBCode(int bCode) {
		BCode = bCode;
	}

	public Date getDTime() {
		return DTime;
	}

	public void setDTime(Date dTime) {
		DTime = dTime;
	}

	public Date getATime() {
		return ATime;
	}

	public void setATime(Date aTime) {
		ATime = aTime;
	}
}
