package pkgPathway;

import java.util.Date;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.*;
import java.text.*;
import java.util.*;

public class Travel {
	String compname; //Company Name
	int cardcoun; //Card Counter
	int sales; //Sales
	Date timedep;
	Date arrtime;
	private int totalsales;
	private String totalmetrocards;
	BufferedReader br;
	public Train trains[];
	public Passenger pass[];
	public Metrocard metros[];
	int tindex;
	int pindex;
	int mindex;
	private Scanner input;
	
	Travel()
{	trains = new Train[8];
	pass = new Passenger[10];
	metros = new Metrocard[4];
	tindex = 0;
	pindex = 0;
	mindex = 0;
	compname = "";
	cardcoun = 0;
	sales = 0;
	timedep = null;
	arrtime = null;
	}
	
	Travel(String c2, int c3, int s)
{	trains = new Train[8];
	pass = new Passenger[10];
	metros = new Metrocard[4];
	tindex = 0;
	pindex = 0;
	mindex = 0;
	compname = c2;
	cardcoun = c3;
	sales = s;
	timedep = null;
	arrtime = null;
	}

	void loadPassenger() throws FileNotFoundException, IOException
	{ 
	BufferedReader inputFile = new BufferedReader(new FileReader("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Passenger.txt")); //save the cars file in the src folder   
	String idpass = "", namepass = "", ccnumpass = "", tinpass = ""; 
	int i = 0;     
	String line = inputFile.readLine(); 
	while (line != null)   
	{ 		StringTokenizer st = new StringTokenizer(line,","); //StringTokenizer separates each token (String) based on the delimiter (comma)    
			idpass = st.nextToken();    
			namepass = st.nextToken();    
			ccnumpass = st.nextToken();        
			tinpass = st.nextToken();
			
			pass[i] = new Passenger(Integer.parseInt(idpass), ccnumpass, tinpass, String.substring(namepass));
			i++; //update the index for the line in the file    
			line = inputFile.readLine();
	}
	
	inputFile.close(); //close the file   
	System.out.println("Load Passengers Completed");  
	}
	 
	void loadTrain() throws FileNotFoundException, IOException
	{ 
	BufferedReader inputFile = new BufferedReader(new FileReader("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Train.txt")); //save the cars file in the src folder   
	String numtrain = "", depstation = "", arrstation = "", boroughcode = "", timedep = "", arrtime = ""; 
	int i = 0;     
	String line = inputFile.readLine(); 
	while (line != null)   
	{ 		StringTokenizer st = new StringTokenizer(line,","); //StringTokenizer separates each token (String) based on the delimiter (comma)    
				numtrain = st .nextToken();    
				depstation = st.nextToken();    
				arrstation = st.nextToken();        
				boroughcode = st.nextToken();
				timedep = st.nextToken();
				arrtime = st.nextToken();
			
			trains[i] = new Train(Integer.parseInt(numtrain), depstation, arrstation, boroughcode, String.substring(timedep), arrtime);
			i++; //update the index for the line in the file    
			line = inputFile.readLine();
	}
	
	inputFile.close(); //close the file   
	System.out.println("Load Train Completed");  
	}
	
	void loadMetrocard() throws FileNotFoundException, IOException
	{ 
	BufferedReader inputFile = new BufferedReader(new FileReader("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Metrocard.txt")); //save the cars file in the src folder   
	String mnum = "", mamt = "";
	int i = 0;     
	String line = inputFile.readLine(); 
	while (line != null)   
	{ 		StringTokenizer st = new StringTokenizer(line,","); //StringTokenizer separates each token (String) based on the delimiter (comma)    
			mnum = st.nextToken();    
			mamt = st.nextToken();   
			
			metros[i] = new Metrocard(Integer.parseInt(mnum), Float.parseFloat(mamt));
			i++; //update the index for the line in the file    
			line = inputFile.readLine();
	}
	
	inputFile.close(); //close the file   
	System.out.println("Load Metrocard Completed");  
	} 

	void login() throws IOException
	
	{	String enteredid = "";
		String enteredtin = "";
		boolean match = false;
		
		System.out.println("Welcome to Metro Scheduling System");
		System.out.println("Enter your Passenger ID and TIN: ");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		System.out.println(dateFormat.format(cal.getTime()));
		enteredid = br.readLine();
		for (int i = 0; i <pass.length;i++)
		{
			if(Integer.parseInt(enteredid) == pass[i].getIdpass())
			{ match = true;
				break;
			}
		}
		if (!match)
			System.out.println("Invalid Passenger ID and TIN, program terminated");
			System.exit(0);
		}	

	int displaymenu() {
	int option;
	
	input = new Scanner(System.in);
	
	do {
            do {
                String menu = "\n Select a choice"
                                + "\n1 1) Process a travel planner"
                                + "\n2 2) Purchase a Metrocard"
                                + "\n3 3) Exit the program";
    System.out.println(menu);
	option = input.nextInt();
	} while(option < 0 || option > 3); // This will make the menu repeat if option is higher than 3 or lower than 0.
	
    switch (option) {
    case 1:
      System.out.println("Process a travel planner");
      return option;
    case 2:
      System.out.println("Purchase a Metrocard");
      return option;
    case 3:
      System.out.println("Exit the program");
      return option;
    default:
      System.out.println("Invalid selection");
      return option;
	  }
        } while (option != 0);
    }
	
	void processTravel(int index)
	{                  
	//Show a list of pickup station and let the user choose
    //Validate the choice (3x maximum)
    //Repeat above 2 steps for the arrival station
    //Call the displayTravelPlan method
	}
	
	void displayTravelPlan(int index)
	{ 
	//Display the current date and time, customer name, train letters, departure Station, 
	//departure time, arrival station, arrival time and connecting train (if applicable)
    //Ask the user do they want to purchase a metrocard?
    //If yes, call the purchase method for the Metrocard passing the Passenger to it
	}
	
	void sellMetrocard(int salesindex, String metrocard, int numsold, float price)
	{
		BufferedWriter outputFile = new BufferedWriter(new FileWriter("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Metrocard.txt", true));
		//A Date format to capture the date and time sold.
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		//get current date time with Date()
		Date date = new Date();
		totalmetrocards += numsold;
		totalsales += price;
		outputFile.write(metrocards[salesindex].Metrocard+"," + numsold+ "," +price +","+dateFormat.format(date));
		outputFile.flush(); //clear out the computer memory
		outputFile.close(); //close the file
	}
	void writeSales() throws FileNotFoundException, IOException   
	{ 		BufferedWriter outputFile = new BufferedWriter(new FileWriter("sales.txt", true));     
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");       
			
			//get current date time with Date()    
			Date date = new Date(); 
	 
			outputFile.write(totalmetrocards+"," + totalsales + "," + dateFormat.format(date) );    
			outputFile.flush();    
			outputFile.close();  
	} 
}

