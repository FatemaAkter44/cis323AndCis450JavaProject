package pkgPathway;

public class Pathways {

	public static void main(String[] args) {
		
		Travel t;
		
		/*try {
	    	   t = new Travel();
			   
			   t.login();
			   t.loadPassenger();
			   t.loadTrain();
			   t.loadMetrocard();
			   t.displaymenu();
	       }
		
		catch (IOException e) {
		       System.out.println("Error finding data files, program terminated");
		}
		catch (FileNotFoundException e) {
			 System.out.println("Error loading data files, program terminated");
		}
		catch (NumberFormatException e) {
		       System.out.println("Invalid choice, program terminated");
		}
		
		finally {
		       System.out.println("Files loaded");
		       }*/
	}
}
