package pkgPathway;

import java.util.Date;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.*;
import java.text.*;
import java.util.*;

@SuppressWarnings("unused")
public class Travel {
	String compname; //Company Name
	int cardcoun; //Card Counter
	int sales; //Sales
	Date timedep;
	Date arrtime;
	float totalsales;
	private String totalmetrocards;
	BufferedReader br;
	public Train trains[];
	public Passenger pass[];
	public Metrocard metros[];
	int cardctr;
	int tindex;
	int pindex;
	int mindex;
	int cardnum;
	private Scanner input;
	private Object wantpur;
	
	
	Travel()
{	br = new BufferedReader(new InputStreamReader(System.in));
	trains = new Train[8];
	pass = new Passenger[10];
	metros = new Metrocard[4];
	cardctr = 0;
	tindex = -1;
	pindex = -1;
	mindex = -1;
	cardnum = 0;
	totalsales = 0.00f;
	compname = "Metro Scheduling System";
	cardcoun = 0;
	sales = 0;
	timedep = null;
	arrtime = null;
	}
	
	Travel(String c2, int c3, int s)
{	trains = new Train[8];
	pass = new Passenger[10];
	metros = new Metrocard[4];
	tindex = 0;
	pindex = 0;
	mindex = 0;
	compname = c2;
	cardcoun = c3;
	sales = s;
	timedep = null;
	arrtime = null;
	}

	@SuppressWarnings("unused")
	void loadPassenger() throws FileNotFoundException, IOException
	{ 
	BufferedReader inputFile = new BufferedReader(new FileReader("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Passenger.txt")); //save the cars file in the src folder   
	String idpass = "", ccnumpass = "", tinpass = ""; String namepass = "";
	int i = 0;     
	String line = inputFile.readLine(); 
	while (line != null)   
	{ 		StringTokenizer st = new StringTokenizer(line,","); //StringTokenizer separates each token (String) based on the delimiter (comma)    
			idpass = st.nextToken();    
			namepass = st.nextToken();    
			ccnumpass = st.nextToken();        
			tinpass = st.nextToken();
			
			pass[i] = new Passenger();
			i++; //update the index for the line in the file    
			line = inputFile.readLine();
	}
	
	inputFile.close(); //close the file   
	System.out.println("Load Passengers Completed");  
	}
	 
	@SuppressWarnings("unused")
	void loadTrain() throws FileNotFoundException, IOException
	{ 
	BufferedReader inputFile = new BufferedReader(new FileReader("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Train.txt")); //save the cars file in the src folder   
	String numtrain = "", depstation = "", arrstation = "", boroughcode = "", timedep = "", arrtime = ""; 
	int i = 0;     
	String line = inputFile.readLine(); 
	while (line != null)   
	{ 		StringTokenizer st = new StringTokenizer(line,","); //StringTokenizer separates each token (String) based on the delimiter (comma)    
				numtrain = st .nextToken();    
				depstation = st.nextToken();    
				arrstation = st.nextToken();        
				boroughcode = st.nextToken();
				timedep = st.nextToken();
				arrtime = st.nextToken();
			//new Train(charAt(0))
			trains[i] = new Train();
			i++; //update the index for the line in the file    
			line = inputFile.readLine();
	}
	
	inputFile.close(); //close the file   
	System.out.println("Load Train Completed");  
	}
	
	void loadMetrocard() throws FileNotFoundException, IOException
	{ 
	BufferedReader inputFile = new BufferedReader(new FileReader("E:\\CIS232\\Project CIS 232\\prj Pathway\\src\\pkgPathway\\Metrocard.txt")); //save the cars file in the src folder   
	String mnum = "", mamt = "";
	int i = 0;     
	String line = inputFile.readLine(); 
	while (line != null)   
	{ 		StringTokenizer st = new StringTokenizer(line,","); //StringTokenizer separates each token (String) based on the delimiter (comma)    
			mnum = st.nextToken();    
			mamt = st.nextToken();   
			
			metros[i] = new Metrocard(Integer.parseInt(mnum), Float.parseFloat(mamt));
			i++; //update the index for the line in the file    
			line = inputFile.readLine();
	}
	
	inputFile.close(); //close the file   
	System.out.println("Load Metrocard Completed");  
	} 

	@SuppressWarnings("unused")
	void login() throws IOException
	
	{	String enteredid = "";
		String enteredtin = "";
		boolean match = false;
		
		System.out.println("Welcome to Metro Scheduling System");
		System.out.println("Enter your Passenger ID and TIN: ");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		System.out.println(dateFormat.format(cal.getTime()));
		enteredid = br.readLine();
		for (int i = 0; i <pass.length;i++)
		{
			if(Integer.parseInt(enteredid) == pass[i].getIdpass())
			{ match = true;
				break;
			}
		}
		if (!match)
			System.out.println("Invalid Passenger ID and TIN, program terminated");
			System.exit(0);
		}	

	int displaymenu() {
	int option;
	
	input = new Scanner(System.in);
	
	do {
            do {
                String menu = "\n Select a choice"
                                + "\n1 1) Process a travel planner"
                                + "\n2 2) Purchase a Metrocard"
                                + "\n3 3) Exit the program";
    System.out.println(menu);
	option = input.nextInt();
	} while(option < 0 || option > 3); // This will make the menu repeat if option is higher than 3 or lower than 0.
	
    switch (option) {
    case 1:
      System.out.println("Process a travel planner");
      return option;
    case 2:
      System.out.println("Purchase a Metrocard");
      return option;
    case 3:
      System.out.println("Exit the program");
      return option;
    default:
      System.out.println("Invalid selection");
      return option;
	  }
        } while (option != 0);
    }
	
	int processTravel(int index)
	{   
		int choice;
		
		input = new Scanner(System.in);
		
		do {
	            do {
	                String list = "\n Select pickup station from list: "
	                                + "\n1 1) Grand Street East"
	                                + "\n2 2) Grand Street West"
	                                + "\n3 3) East Flatbush North"
	                                + "\n4 4) East Flatbush South"
	                                + "\n5 5) Far Rockaway West"
	                                + "\n6 6) Far Rockaway East"
	                                + "\n7 7) Harlem Plaza South"
	                                + "\n8 8) Harlem Plaza North"
	                                + "\n9 9) Exit the program";
	    System.out.println(list);
		choice = input.nextInt();
		} while(choice < 0 || choice > 3);
		
	    switch (choice) {
	    case 1:
	      System.out.println("Grand Street East");
	      return choice;
	    case 2:
	      System.out.println("Grand Street West");
	      return choice;
	    case 3:
	      System.out.println("East Flatbush North");
		  return choice;
		case 4:
		  System.out.println("East Flatbush South");
		  return choice;
		case 5:
		  System.out.println("Far Rockaway West");
		  return choice;
		case 6:
	      System.out.println("Far Rockaway East");
		  return choice;
		case 7:
		  System.out.println("Harlem Plaza South");
		  return choice;
		case 8:
		  System.out.println("Harlem Plaza North");
		  return choice;
	    case 9:
	      System.out.println("Exit the program");
	      return choice;
	    default:
	      System.out.println("Invalid selection");
	      return choice;
		  }
	        } while (choice != 0);
	    }
	
	void displayTravelPlan(int index) throws IOException
	{ 
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		System.out.println(dateFormat.format(cal.getTime()));

			String namepass = "x";
			String TNumber = "x";
			String DStation = "x";
			String DTime = "x";
			String AStation = "x";
			String ATime = "x";
			System.out.println("Do they want to purchase a metrocard?: (Y/N)");
			wantpur = br.readLine();
			
			if (wantpur.equals("Y"))
			{	totalsales += mindex;	}
			return;
		}
	
	void calculateSales(float price)
	{	
		totalsales += price;
		System.out.print("Thank You For Your Purchase");
	}
	
	void writeSales() throws FileNotFoundException, IOException   
	{ 		BufferedWriter outputFile = new BufferedWriter(new FileWriter("sales.txt", true));     
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");       
			
			//get current date time with Date()    
			Date date = new Date(); 
	 
			outputFile.write(totalmetrocards+"," + totalsales + "," + dateFormat.format(date) );    
			outputFile.flush();    
			outputFile.close();  
	} 
}

